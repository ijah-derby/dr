export class NavUser {
    static userId: string;
}