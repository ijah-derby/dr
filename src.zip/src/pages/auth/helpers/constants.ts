export enum SocialAuthProvider {
  google,
  facebook
}
