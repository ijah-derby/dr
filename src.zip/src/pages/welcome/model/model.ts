export interface IWelcomeSlides {
  image: string;
  title: string;
  paragraph: string;
}
