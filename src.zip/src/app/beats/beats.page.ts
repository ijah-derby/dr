import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-beats',
  templateUrl: './beats.page.html',
  styleUrls: ['./beats.page.scss'],
})
export class BeatsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
