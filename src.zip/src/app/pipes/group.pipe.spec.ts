import { GroupPipe } from './group.pipe';

describe('GroupPipe', () => {
  it('create an instance', () => {
    const pipe = new GroupPipe();
    expect(pipe).toBeTruthy();
  });
});
