import { FriendPipe } from './friend.pipe';

describe('FriendPipe', () => {
  it('create an instance', () => {
    const pipe = new FriendPipe();
    expect(pipe).toBeTruthy();
  });
});
