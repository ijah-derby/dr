import { ConversationPipe } from './conversation.pipe';

describe('ConversationPipe', () => {
  it('create an instance', () => {
    const pipe = new ConversationPipe();
    expect(pipe).toBeTruthy();
  });
});
