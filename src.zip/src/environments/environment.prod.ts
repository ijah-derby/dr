
export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyA2kx6yOWOUW8kkwX74fNZ-x9_3MooHF7E',
    authDomain: 'iderby-music.firebaseapp.com',
    databaseURL: 'https://iderby-music.firebaseio.com',
    projectId: 'iderby-music',
    storageBucket: 'iderby-music.appspot.com',
    messagingSenderId: '46838646293',
    appId: '1:46838646293:android:031018036ca5e25b'
  },
  googleClientId: '46838646293-u050v8t1e5q1gtspa45gkmeu9p7jm46h.apps.googleusercontent.com',
  hosting: 'https://app.dontramp.com',
  firebaseConfig: {
   apiKey: 'AIzaSyA2kx6yOWOUW8kkwX74fNZ-x9_3MooHF7E',
    authDomain: 'iderby-music.firebaseapp.com',
    databaseURL: 'https://iderby-music.firebaseio.com',
    projectId: 'iderby-music',
    storageBucket: 'iderby-music.appspot.com',
    messagingSenderId: '46838646293',
    appId: '1:46838646293:android:031018036ca5e25b'
  }
};
