import { InputRefDirective } from './input-ref.directive';

describe('InputRefDirective', () => {
  it('should create an instance', () => {
    const directive = new InputRefDirective(null, null);
    expect(directive).toBeTruthy();
  });
});
