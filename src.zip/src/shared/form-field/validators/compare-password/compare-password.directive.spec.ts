import { ComparePasswordDirective } from './compare-password.directive';

describe('ComparePasswordDirective', () => {
  it('should create an instance', () => {
    const directive = new ComparePasswordDirective();
    expect(directive).toBeTruthy();
  });
});
