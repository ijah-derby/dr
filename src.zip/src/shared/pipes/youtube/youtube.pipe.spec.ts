import { YoutubePipe } from './youtube.pipe';

describe('YoutubePipe', () => {
  it('create an instance', () => {
    const pipe = new YoutubePipe();
    expect(pipe).toBeTruthy();
  });
});
