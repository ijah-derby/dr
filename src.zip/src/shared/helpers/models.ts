export interface ITabView {
  id: any;
  icon?: string;
  name: string;
  active?: boolean;
  event?: any;
}
