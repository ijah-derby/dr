import { ColorLuminanceDirective } from './color-luminance.directive';

describe('ColorLuminanceDirective', () => {
  it('should create an instance', () => {
    const directive = new ColorLuminanceDirective(null);
    expect(directive).toBeTruthy();
  });
});
