import { ElasticDirective } from './elastic.directive';

describe('ElasticDirective', () => {
  it('should create an instance', () => {
    const directive = new ElasticDirective(null);
    expect(directive).toBeTruthy();
  });
});
